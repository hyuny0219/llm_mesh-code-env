import threading

pypdfium2_lock = threading.Lock()
