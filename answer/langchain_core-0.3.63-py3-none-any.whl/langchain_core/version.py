"""langchain-core version information and utilities."""

VERSION = "0.3.63"
