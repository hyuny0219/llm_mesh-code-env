from qdrant_client.models import Document  # type: ignore[attr-defined]

__all__ = ["Document"]
